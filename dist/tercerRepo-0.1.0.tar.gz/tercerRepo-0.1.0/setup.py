from setuptools import setup, find_packages

setup(
    name="tercerRepo",                              # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Rodrigo Hug",                           # Tu nombre
    author_email="rodrigohug2017@gmail.com",        # Tu correo electrónico
    url="https://github.com/platzi/git-github",     # URL del proyecto
)